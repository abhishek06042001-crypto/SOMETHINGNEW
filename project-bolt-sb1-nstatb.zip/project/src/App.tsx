import React from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import FaceSwap from './components/FaceSwap';

function App() {
  return (
    <div className="min-h-screen bg-gray-900">
      <Navbar />
      <div className="pt-16">
        <Hero />
        <FaceSwap />
      </div>
    </div>
  );
}

export default App;