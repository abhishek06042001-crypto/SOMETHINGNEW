import React, { useState, useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import Webcam from 'react-webcam';
import { Upload, Camera, Image as ImageIcon, Loader, Video, FileVideo } from 'lucide-react';
import ResultPreview from './ResultPreview';
import { processImageFaceSwap } from '../utils/faceSwap';

type MediaType = 'image' | 'video';

export default function FaceSwap() {
  const [sourceImage, setSourceImage] = useState<string | null>(null);
  const [targetMedia, setTargetMedia] = useState<string | null>(null);
  const [targetType, setTargetType] = useState<MediaType>('image');
  const [isProcessing, setIsProcessing] = useState(false);
  const [showWebcam, setShowWebcam] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const webcamRef = React.useRef<Webcam>(null);

  const onDrop = useCallback((acceptedFiles: File[], type: 'source' | 'target') => {
    const file = acceptedFiles[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        if (type === 'source') {
          setSourceImage(e.target?.result as string);
        } else {
          setTargetMedia(e.target?.result as string);
          setTargetType(file.type.startsWith('video/') ? 'video' : 'image');
        }
      };
      reader.readAsDataURL(file);
    }
  }, []);

  const { getRootProps: getSourceProps, getInputProps: getSourceInputProps } = useDropzone({
    onDrop: (files) => onDrop(files, 'source'),
    accept: { 'image/*': [] },
    maxFiles: 1,
  });

  const { getRootProps: getTargetProps, getInputProps: getTargetInputProps } = useDropzone({
    onDrop: (files) => onDrop(files, 'target'),
    accept: { 'image/*': [], 'video/*': [] },
    maxFiles: 1,
  });

  const captureWebcam = useCallback(() => {
    if (webcamRef.current) {
      const imageSrc = webcamRef.current.getScreenshot();
      setTargetMedia(imageSrc);
      setTargetType('image');
      setShowWebcam(false);
    }
  }, []);

  const processImages = async () => {
    if (!sourceImage || !targetMedia) return;
    
    setIsProcessing(true);
    setError(null);
    
    try {
      if (targetType === 'image') {
        const swappedImage = await processImageFaceSwap(sourceImage, targetMedia);
        setResult(swappedImage);
      } else {
        // For video, we'll just use a placeholder for now
        // In a real implementation, you'd process each frame
        setResult(targetMedia);
      }
    } catch (err) {
      setError('Failed to process face swap. Please try again.');
      console.error(err);
    } finally {
      setIsProcessing(false);
    }
  };

  const resetAll = () => {
    setSourceImage(null);
    setTargetMedia(null);
    setResult(null);
    setIsProcessing(false);
    setShowWebcam(false);
    setError(null);
  };

  if (result) {
    return <ResultPreview result={result} isVideo={targetType === 'video'} onReset={resetAll} />;
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Source Image Upload */}
        <div className="space-y-4">
          <h2 className="text-xl font-semibold text-white">Source Face</h2>
          <div
            {...getSourceProps()}
            className="border-2 border-dashed border-gray-700 rounded-lg p-8 hover:border-purple-500 transition-colors"
          >
            <input {...getSourceInputProps()} />
            {sourceImage ? (
              <img src={sourceImage} alt="Source" className="max-h-64 mx-auto rounded-lg" />
            ) : (
              <div className="text-center">
                <Upload className="mx-auto h-12 w-12 text-gray-400" />
                <p className="mt-2 text-sm text-gray-400">Drag & drop or click to upload source face</p>
              </div>
            )}
          </div>
        </div>

        {/* Target Media Upload */}
        <div className="space-y-4">
          <h2 className="text-xl font-semibold text-white">Target {targetType === 'video' ? 'Video' : 'Image'}</h2>
          {showWebcam ? (
            <div className="space-y-4">
              <Webcam
                ref={webcamRef}
                screenshotFormat="image/jpeg"
                className="w-full rounded-lg"
              />
              <button
                onClick={captureWebcam}
                className="w-full py-2 px-4 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition"
              >
                Capture Photo
              </button>
            </div>
          ) : (
            <div
              {...getTargetProps()}
              className="border-2 border-dashed border-gray-700 rounded-lg p-8 hover:border-purple-500 transition-colors"
            >
              <input {...getTargetInputProps()} />
              {targetMedia ? (
                targetType === 'video' ? (
                  <video
                    src={targetMedia}
                    className="max-h-64 mx-auto rounded-lg"
                    controls
                  />
                ) : (
                  <img src={targetMedia} alt="Target" className="max-h-64 mx-auto rounded-lg" />
                )
              ) : (
                <div className="text-center">
                  <Upload className="mx-auto h-12 w-12 text-gray-400" />
                  <p className="mt-2 text-sm text-gray-400">
                    Drag & drop or click to upload target {targetType}
                  </p>
                  <p className="mt-1 text-xs text-gray-500">
                    Supports both images and videos
                  </p>
                </div>
              )}
            </div>
          )}
          
          <div className="flex gap-4">
            <button
              onClick={() => setShowWebcam(!showWebcam)}
              className="flex-1 py-2 px-4 bg-gray-800 text-white rounded-lg hover:bg-gray-700 transition flex items-center justify-center gap-2"
            >
              {showWebcam ? <ImageIcon className="h-5 w-5" /> : <Camera className="h-5 w-5" />}
              {showWebcam ? 'Switch to Upload' : 'Use Webcam'}
            </button>
            
            <button
              onClick={() => {
                setTargetType(targetType === 'video' ? 'image' : 'video');
                setTargetMedia(null);
              }}
              className="flex-1 py-2 px-4 bg-gray-800 text-white rounded-lg hover:bg-gray-700 transition flex items-center justify-center gap-2"
            >
              {targetType === 'video' ? (
                <ImageIcon className="h-5 w-5" />
              ) : (
                <FileVideo className="h-5 w-5" />
              )}
              Switch to {targetType === 'video' ? 'Image' : 'Video'}
            </button>
          </div>
        </div>
      </div>

      {/* Error Message */}
      {error && (
        <div className="mt-4 p-4 bg-red-900/50 border border-red-500 rounded-lg text-red-200">
          {error}
        </div>
      )}

      {/* Process Button */}
      <div className="mt-8 flex justify-center">
        <button
          onClick={processImages}
          disabled={!sourceImage || !targetMedia || isProcessing}
          className={`
            py-3 px-8 rounded-lg flex items-center gap-2
            ${isProcessing || !sourceImage || !targetMedia
              ? 'bg-gray-700 cursor-not-allowed'
              : 'bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-600 hover:to-pink-700'}
            text-white font-medium transition
          `}
        >
          {isProcessing ? (
            <>
              <Loader className="h-5 w-5 animate-spin" />
              Processing...
            </>
          ) : (
            'Process Face Swap'
          )}
        </button>
      </div>

      {/* Processing Preview */}
      {isProcessing && (
        <div className="mt-8 p-8 border border-gray-700 rounded-lg">
          <div className="animate-pulse flex justify-center">
            <div className="h-64 w-full bg-gray-700 rounded-lg"></div>
          </div>
        </div>
      )}
    </div>
  );
}