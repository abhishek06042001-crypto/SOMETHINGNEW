import React from 'react';
import { Box, Upload, Zap, Lock } from 'lucide-react';

export default function Hero() {
  return (
    <div className="relative overflow-hidden bg-gray-900">
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-gradient-to-r from-purple-900/30 to-pink-900/30" />
      </div>
      
      <div className="max-w-7xl mx-auto relative">
        <div className="relative z-10 pb-8 sm:pb-16 md:pb-20 lg:w-full lg:pb-28 xl:pb-32">
          <main className="mt-10 mx-auto max-w-7xl px-4 sm:mt-12 sm:px-6 md:mt-16 lg:mt-20 lg:px-8 xl:mt-28">
            <div className="sm:text-center lg:text-left">
              <h1 className="text-4xl tracking-tight font-extrabold sm:text-5xl md:text-6xl">
                <span className="block text-white">Transform Reality with</span>
                <span className="block text-gradient">3D Face Swaps</span>
              </h1>
              <p className="mt-3 text-base text-gray-300 sm:mt-5 sm:text-lg sm:max-w-xl sm:mx-auto md:mt-5 md:text-xl lg:mx-0">
                Experience the next generation of AI face transformation. Create stunning, ethical deepfakes with our cutting-edge 3D technology.
              </p>
              <div className="mt-5 sm:mt-8 sm:flex sm:justify-center lg:justify-start">
                <div className="rounded-md shadow">
                  <button className="w-full flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium rounded-md text-white bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-600 hover:to-pink-700 md:py-4 md:text-lg md:px-10 transition">
                    Start Creating
                  </button>
                </div>
                <div className="mt-3 sm:mt-0 sm:ml-3">
                  <button className="w-full flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium rounded-md text-purple-400 bg-gray-800 hover:bg-gray-700 md:py-4 md:text-lg md:px-10 transition">
                    Watch Demo
                  </button>
                </div>
              </div>
            </div>
          </main>
        </div>
      </div>
      
      <div className="lg:absolute lg:inset-y-0 lg:right-0 lg:w-1/2">
        <img
          className="h-56 w-full object-cover sm:h-72 md:h-96 lg:w-full lg:h-full opacity-80"
          src="https://images.unsplash.com/photo-1633355444132-695d5876cd00?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=2070&q=80"
          alt="3D Face Technology"
        />
        <div className="absolute inset-0 bg-gradient-to-l from-gray-900/0 via-gray-900/0 to-gray-900" />
      </div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 relative">
        <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-4">
          <Feature 
            icon={<Box className="h-6 w-6 text-purple-400" />}
            title="3D Processing"
            description="Advanced 3D modeling and rendering technology"
          />
          <Feature 
            icon={<Upload className="h-6 w-6 text-purple-400" />}
            title="Easy Import"
            description="Drag & drop your assets for instant processing"
          />
          <Feature 
            icon={<Zap className="h-6 w-6 text-purple-400" />}
            title="Real-time Preview"
            description="See changes instantly with live 3D preview"
          />
          <Feature 
            icon={<Lock className="h-6 w-6 text-purple-400" />}
            title="Secure Platform"
            description="Enterprise-grade security for your content"
          />
        </div>
      </div>
    </div>
  );
}

function Feature({ icon, title, description }: { icon: React.ReactNode, title: string, description: string }) {
  return (
    <div className="card-3d flex flex-col items-center text-center p-6 bg-gray-800/50 rounded-xl border border-gray-700 hover:border-purple-500/50">
      <div className="flex items-center justify-center w-12 h-12 rounded-full bg-purple-900/50">
        {icon}
      </div>
      <h3 className="mt-4 text-lg font-medium text-white">{title}</h3>
      <p className="mt-2 text-sm text-gray-400">{description}</p>
    </div>
  );
}