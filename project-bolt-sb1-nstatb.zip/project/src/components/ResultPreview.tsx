import React from 'react';
import ReactPlayer from 'react-player';
import { Download, Share2, Undo2 } from 'lucide-react';

interface ResultPreviewProps {
  result: string;
  isVideo: boolean;
  onReset: () => void;
}

export default function ResultPreview({ result, isVideo, onReset }: ResultPreviewProps) {
  const handleDownload = () => {
    const link = document.createElement('a');
    link.href = result;
    link.download = `faceswap-result.${isVideo ? 'mp4' : 'png'}`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="mt-8">
      <div className="bg-gray-800 rounded-xl overflow-hidden">
        <div className="p-4 border-b border-gray-700">
          <h3 className="text-lg font-semibold text-white">Result Preview</h3>
        </div>
        
        <div className="p-4">
          {isVideo ? (
            <div className="aspect-video rounded-lg overflow-hidden">
              <ReactPlayer
                url={result}
                width="100%"
                height="100%"
                controls
                playing
                loop
              />
            </div>
          ) : (
            <img 
              src={result} 
              alt="Face Swap Result" 
              className="w-full rounded-lg"
            />
          )}
        </div>

        <div className="p-4 bg-gray-900/50 border-t border-gray-700">
          <div className="flex flex-wrap gap-4">
            <button
              onClick={handleDownload}
              className="flex items-center gap-2 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition"
            >
              <Download className="h-4 w-4" />
              Download
            </button>
            
            <button
              onClick={() => navigator.clipboard.writeText(result)}
              className="flex items-center gap-2 px-4 py-2 bg-gray-700 text-white rounded-lg hover:bg-gray-600 transition"
            >
              <Share2 className="h-4 w-4" />
              Copy Link
            </button>

            <button
              onClick={onReset}
              className="flex items-center gap-2 px-4 py-2 bg-gray-700 text-white rounded-lg hover:bg-gray-600 transition ml-auto"
            >
              <Undo2 className="h-4 w-4" />
              Start Over
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}